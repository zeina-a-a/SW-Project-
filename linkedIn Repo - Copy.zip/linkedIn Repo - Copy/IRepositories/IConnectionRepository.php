<?php

interface IConnectionRepository
{
    public function getUserConnectionsQuery($userId);
}
?>