<?php

interface IBaseJobRepository
{
    public function getAllJobsQuery();
}