<?php

interface ISearchRepository {
    public function searchUsers($username);
} 